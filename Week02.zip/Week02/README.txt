1. Use Jupiter notebook or VSCode to open it.
2. Runall all the code.
3. Upload problem2.csv as requested